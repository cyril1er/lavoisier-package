
$(document).ready(function ($) {

    /**
     * Fonction qui ajoute la class label correcte (success , warning..) au span de class label en fonction de la valeur du title
     *
     * @param percent
     * @returns {string}
     */
    var getColorClass = function(percent){

        classname="";

        if (percent > 80)
            classname="label-success";

        if (percent < 80)
            classname="label-warning";

        if (percent < 50)
            classname="label-important";

        if (percent < 1)
            classname="label-inverse";




        return classname;
    }

    // set the first colors
    $('td').find('span.label').each(function () {
        $(this).addClass(getColorClass($(this).attr('title')));
    });




    var getColorClass2 = function(percent){

       

        if (percent > 5)
            classname="badge-important";

        if (percent <= 5)
            classname="badge-warning";

        if (percent <= 1)
            classname="badge-success";


        if (percent == 'Nan')
            classname="badge-success";

        return classname;
    }


    // set the first colors
    $('td').find('span.badge').each(function () {
        $(this).addClass(getColorClass2($(this).attr('title')));
    });



});



















